package com.nandha.first_springboot_web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstSpringbootWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
