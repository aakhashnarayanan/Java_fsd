package beans;

public class Car {
	private int carId;
	private String carName;
	private String CompanyName;
	
	public Car(int carId, String carName, String companyName) {
		super();
		this.carId = carId;
		this.carName = carName;
		CompanyName = companyName;
	}

	public int getCarId() {
		return carId;
	}

	public void setCarId(int carId) {
		this.carId = carId;
	}

	public String getCarName() {
		return carName;
	}

	public void setCarName(String carName) {
		this.carName = carName;
	}

	public String getCompanyName() {
		return CompanyName;
	}

	public void setCompanyName(String companyName) {
		CompanyName = companyName;
	}
	
}
