package controllers;

import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import beans.Car;

@RestController
public class AppController {
	
	@GetMapping("/getcars")
	public List<Car> giveBooks(){
		return Arrays.asList(new Car(1, "Swift", "Maruthi"), new Car(1, "Innova", "Toyato"), new Car(2, "Audi R8", "Audi"));
	}
}
