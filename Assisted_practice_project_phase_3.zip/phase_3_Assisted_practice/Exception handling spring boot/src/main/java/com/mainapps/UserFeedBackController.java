package com.mainapps;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/user")
public class UserFeedBackController {
	
	@Autowired
	JpaRepoClass jpaRepo;
	
	@GetMapping("/getusers")
	public List<User> getUsers(){
		return jpaRepo.findAll();
	}
	
	@PostMapping("/register")
	public void registerUser(@RequestBody User u){
		jpaRepo.insert(u);
	}
	
	@DeleteMapping("/delete")
	public void delete(int id){
		jpaRepo.deleteById(id);
	}
	
	@GetMapping("/getuser/{id}")
	public User getUser(@PathVariable("id") int id) {
		User u = jpaRepo.findById(id);
		if(u==null) {
			throw new UserNotFoundExceptionClass();
		}else {
			return u;
		}
	}
}
