package com.mainapps;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public class JpaRepoClass {
	
	@PersistenceContext
	EntityManager entityManager;
	
	public List<User> findAll(){
		TypedQuery<User> namedQuery = entityManager.createNamedQuery("find_all_users",User.class);
		return namedQuery.getResultList();
	}
	
	public User insert(User u) {
		return entityManager.merge(u);
	}
	
	public User update(User u) {
		return entityManager.merge(u);
	}
	
	public User findById(int id) {
		return entityManager.find(User.class, id);
	}
	
	public void deleteById(int id) {
		User u = findById(id);
		entityManager.remove(u);
	}

}
